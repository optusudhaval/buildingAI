# Environment for building Artificial Intelligence (AI) - outlining the interaction of Google Colab with the different tools and technologies.

![Environment for building AI - outlining the interaction of Google Colab with the different tools and technologies](https://drive.google.com/uc?id=1KqcH0SqhE05Kk0YJINiQM3fiOwyUqBVb)